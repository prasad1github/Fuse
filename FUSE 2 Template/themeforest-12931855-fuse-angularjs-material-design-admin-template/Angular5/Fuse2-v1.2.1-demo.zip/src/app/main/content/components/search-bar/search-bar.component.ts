import { Component } from '@angular/core';

@Component({
    selector   : 'fuse-search-bar-docs',
    templateUrl: './search-bar.component.html',
    styleUrls  : ['./search-bar.component.scss']
})
export class FuseSearchBarDocsComponent
{
    constructor()
    {

    }
}
