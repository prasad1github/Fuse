import { Component } from '@angular/core';

@Component({
    selector   : 'fuse-pricing-style-1',
    templateUrl: './style-1.component.html',
    styleUrls  : ['./style-1.component.scss']
})
export class FusePricingStyle1Component
{
    constructor()
    {

    }

}
