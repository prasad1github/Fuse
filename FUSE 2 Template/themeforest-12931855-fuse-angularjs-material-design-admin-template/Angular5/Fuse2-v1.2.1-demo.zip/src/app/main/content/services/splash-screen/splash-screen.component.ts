import { Component } from '@angular/core';

@Component({
    selector   : 'fuse-splash-screen-service-docs',
    templateUrl: './splash-screen.component.html',
    styleUrls  : ['./splash-screen.component.scss']
})
export class FuseSplashScreenServiceDocsComponent
{
    constructor()
    {

    }
}
